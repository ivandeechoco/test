
<head>

<link href="cross.png" rel="icon" type="image/x-icon" />
</head>


    <div style="clear:both;color:#000; padding:20px;">

    	<hr /><center></strong>&copy; 2018 <strong><a target="_blank" href="https://web.facebook.com/JobBrioso98">JOB BRIOSO</a></strong></center>

    </div>